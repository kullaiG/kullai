def conflict():
    raise AssertionError('Should not be executed')
