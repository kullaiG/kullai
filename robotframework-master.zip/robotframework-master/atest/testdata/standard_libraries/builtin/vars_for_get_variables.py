var_in_variable_file = 'Hello, world!'
