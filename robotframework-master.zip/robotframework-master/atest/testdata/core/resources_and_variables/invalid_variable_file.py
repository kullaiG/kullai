raise Exception('This is an invalid variable file')
