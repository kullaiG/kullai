var_in_invalid_list_variable_file = 'Not got into use due to error below'
LIST__invalid_list = 'This is not a list and thus importing this file fails'