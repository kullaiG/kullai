raise RuntimeError('Ööööps!')
