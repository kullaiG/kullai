def spaces_in_library_path():
    return "here was a bug"
