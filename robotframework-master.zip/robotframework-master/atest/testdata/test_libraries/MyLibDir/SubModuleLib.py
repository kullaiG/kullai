def keyword_in_mylibdir_submodulelib():
    pass
