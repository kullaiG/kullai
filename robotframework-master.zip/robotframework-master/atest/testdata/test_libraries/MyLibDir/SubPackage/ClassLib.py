class ClassLib:

    def keyword_in_mylibdir_subpackage_classlib(self):
        pass
