class MyLibFile2:

    def keyword_in_my_lib_file_2(self, arg):
        return 'Hello %s!' % arg
