class InitWithOnlyNamedOnlyArgs:

    def __init__(self, *, a=1, b):
        """xxx"""

    def kw(self):
        pass
