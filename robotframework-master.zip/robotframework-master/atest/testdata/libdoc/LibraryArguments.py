class LibraryArguments:

    def __init__(self, required, args: bool, optional=None):
        assert required == 'required'
        assert args is True

    def keyword(self):
        pass
