class JSON:

    def keyword_in_json(self):
        pass


class resource:

    def keyword_in_resource(self):
        pass
