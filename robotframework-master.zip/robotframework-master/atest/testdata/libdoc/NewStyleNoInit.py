class NewStyleNoInit:
    """No inits here!"""

    def keyword(self, arg1, arg2):
        """The only lonely keyword."""
