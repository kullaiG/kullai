Included file with some more test data.

.. code:: robotframework

   *** Settings ***
   Default Tags    default1


The end.
