variable_file = 'variable in variable file'
