def keyword_from_deeper_submodule():
    return 'hi again'


class Sub:

    def keyword_from_class_in_deeper_submodule(self):
        return 'bye'

