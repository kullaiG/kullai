message_list = ['Circle is 360\u00B0',
                'Hyv\u00E4\u00E4 \u00FC\u00F6t\u00E4',
                '\u0989\u09C4 \u09F0 \u09FA \u099F \u09EB \u09EA \u09B9']

message1 = message_list[0]
message2 = message_list[1]
message3 = message_list[2]

messages = ', '.join(message_list)

sect = chr(167)
auml = chr(228)
ouml = chr(246)
uuml = chr(252)
yuml = chr(255)
