robot.running.timeouts package
==============================

.. automodule:: robot.running.timeouts
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

robot.running.timeouts.posix module
-----------------------------------

.. automodule:: robot.running.timeouts.posix
   :members:
   :undoc-members:
   :show-inheritance:

robot.running.timeouts.windows module
-------------------------------------

.. automodule:: robot.running.timeouts.windows
   :members:
   :undoc-members:
   :show-inheritance:
